(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[49683],{

/***/ 586838:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(258551);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var pg=__c.pg;var z0=__c.z0;__c.T0=function(){return{Re:z0.lF(1,{min:0}),Bwa:z0.QGb(2,z0.Jzb()),V:z0.lF(3,{min:0,max:100})}};__c.U0=function(a){return{color:z0.XD(a,__c.A0)}};__c.lgc=function(a,b,c){return{Aa:z0.JSa(a,__c.A0),height:z0.lF(b,{min:1}),width:z0.lF(c,{min:1})}};__c.V0=function(a){return{borderColor:z0.XD(a,__c.A0)}};__c.W0=function(a){return{kd:z0.XD(a,__c.A0)}};
__c.X0=function(a){return{Vv:z0.Bpa(a,{Wd:z0.vC(1,"none","underline"),direction:z0.vC(2,"ltr","rtl"),fontFamily:z0.Rz(3),fontStyle:z0.vC(4,"normal","italic"),fontWeight:z0.vC(5,"normal","thin","extralight","light","medium","semibold","bold","ultrabold","heavy"),letterSpacing:z0.Sj(6,{min:-200,max:800}),lineHeight:z0.Sj(7,{min:500,max:2500}),Rg:z0.vC(8,"none","bulleted","numbered","checked"),size:z0.Sj(9,{min:0}),xj:z0.vC(10,"none","strikethrough"),textAlign:z0.vC(11,"start","center","end","justify"),
textTransform:z0.vC(12,"none","uppercase","lowercase","capitalize")})}};__c.Y0=function(a={}){return{Wd:pg.Tb.decoration,direction:pg.Tb.direction,fontFamily:pg.Tb["font-family"],fontStyle:pg.Tb["font-style"],fontWeight:pg.Tb["font-weight"],letterSpacing:pg.Tb.tracking,lineHeight:pg.Tb.leading,Rg:"none",size:pg.Tb["font-size"],xj:pg.Tb.strikethrough,textAlign:pg.Tb["text-align"],textTransform:pg.Tb["text-transform"],...a}};__c.T0();__c.A0=z0.DMa(/^#[0-9a-fA-F]{6}$/);__c.U0(1);__c.lgc(1,2,3);__c.V0(1);
__c.W0(1);__c.X0(1);
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/045803f4d9844afa.js.map