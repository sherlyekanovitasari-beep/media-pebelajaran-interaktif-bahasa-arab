(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[67942],{

/***/ 138575:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(31541);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.K2=function(a,b,c){a=a.rows.flatMap(d=>d.value_by.Hf(e=>b(e)));if(!a.length)return __c.$1;c=__c.a2({...c,Qla:!1,data:a});return c[0].value===c[1].value?__c.$1:c};__c.L2=function(a,b,c){return a.rows.map((d,e)=>{d=d[b].get(0);d=d!=null?c(d):"";return`${e}.${d}`})};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/0684da11790b716f.js.map