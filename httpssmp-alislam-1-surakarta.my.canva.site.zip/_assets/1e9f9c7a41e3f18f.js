(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[93292],{

/***/ 431459:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(637649);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.hZ=function(a){return`${Math.round(a*1E3)/10}%`};__c.iZ=function(a,b){return __c.KY(a).map("value_by",{data:c=>{let d=0;return c.value_by.values().map(e=>{const f=b(e),g=d;d+=f;return{...e,sA:g,Co:d}})},meta:c=>c.Hf(d=>d.meta),xc:__c.HY}).build()};__c.N$b=function(a,b){return __c.KY(a).map("value_by",{data:c=>{const d=c.value_by.values().reduce((e,f)=>{f=b(f);__c.x(f>=0);return e+f},0);return c.value_by.values().map(e=>({...e,RC:d===0?0:b(e)/d}))},meta:c=>c.Hf(d=>d.meta),xc:__c.HY}).build()};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/1e9f9c7a41e3f18f.js.map