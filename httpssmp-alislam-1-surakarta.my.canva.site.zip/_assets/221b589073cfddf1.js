(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[35464],{

/***/ 454436:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var u8c='<svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M6.914 24a6.914 6.914 0 1 0 0-13.828 6.914 6.914 0 0 0 0 13.828ZM18.5 13a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11Z" fill="#00D9E1"/><path d="M19.425 10.473c1.859-.87 2.5-2.213 2.228-3.713" stroke="#D1EEFC" stroke-width="2.403" stroke-linecap="round" stroke-linejoin="round"/><path d="M7.442 6.871a3.436 3.436 0 1 0 0-6.871 3.436 3.436 0 0 0 0 6.871Z" fill="#BBF3F4"/><path d="M18.466 22.048a3.436 3.436 0 1 0 0-6.871 3.436 3.436 0 0 0 0 6.87Z" fill="#00C4CC"/><path d="M8.62 18.396a2.86 2.86 0 1 0 0-5.719 2.86 2.86 0 0 0 0 5.72Z" fill="#BBF3F4"/></svg>';__c.Y_c={};__c.Y_c.Aib=__c.IT({medium:u8c,Tf:u8c});
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/221b589073cfddf1.js.map