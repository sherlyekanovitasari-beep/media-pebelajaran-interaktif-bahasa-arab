(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[23065],{

/***/ 239349:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.HOb={config:{language:"it-IT",Of:{yMMMd:"d MMM yyyy",yMd:"dd/MM/yyyy",yMMM:"MMM yyyy"},dg:"gen feb mar apr mag giu lug ago set ott nov dic".split(" "),eg:"gennaio febbraio marzo aprile maggio giugno luglio agosto settembre ottobre novembre dicembre".split(" "),Ng:[{pattern:"dd *[/-] *mm *[/-] *yy",na:"yMd"},{pattern:"dd *[/-] *mm *[/-] *yyyy",na:"yMd"},{pattern:"dd *[/-] *mm",na:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/25120f24b50bbc77.js.map