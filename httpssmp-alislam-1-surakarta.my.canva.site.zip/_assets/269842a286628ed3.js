(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[96145],{

/***/ 240411:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var $Oc=__webpack_require__(186901).O8;var aPc;
__c.m0a=class{get Nd(){if(this.OC){this.OC&&(this.Kc.now()>this.OC.a3a+18E5&&(this.OC.id=__c.qn()),this.OC.a3a=this.Kc.now());var a=this.OC.vu,b=this.OC.gg,c=this.OC.wU,d=b.Cb,e=this.OC.gg.$d.v_(d);return{bi:"DAAAAAAAA1",Jc:void 0,mode:c.mode,vu:aPc[a],EIb:this.OC.id,IGa:b.Ip,TEb:b.Ca.ba.count(),kf:b.fe,location:this.location,h8a:b.$d.twb(d),j8a:e==="inline"?"custom":e?.id,zv:d.id}}}track(a,b){this.dnb.track(a,{...b,Nd:$Oc(()=>this.Nd)})}bzb(a){this.OC={id:__c.qn(),a3a:this.Kc.now(),...a};return()=>
this.OC=void 0}constructor(a,b,c=__c.hp){this.dnb=a;this.location=b;this.Kc=c}};aPc={[2]:"viewer",[3]:"viewer",[4]:"investigator",[5]:"commenter",[6]:"editor",[7]:"contentManager",[8]:"admin",[9]:"owner",[1]:void 0};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/269842a286628ed3.js.map