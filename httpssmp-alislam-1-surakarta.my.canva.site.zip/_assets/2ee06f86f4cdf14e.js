(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[79878],{

/***/ 112068:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var gsc=function(a,{gz:b,WE:c,$S:d}){a.Sfb.push(b);a.Q8a.push(c);a.$S=d},hsc=class{PTa(a){a=a.config;const b=this.$S?.(a.ref);var c;if(c=b)a:{if(__c.$D.has(a.ref.type))for(var d of b.filters)if(b.Zu(d).isDirty){c=!0;break a}c=!1}if(c)return d=this.gz(a.ref),a=this.WE(a.ref),{top:d.top-a.top,left:d.left-a.left,bottom:d.bottom-a.bottom,right:d.right-a.right}}gz(a){for(const b of this.Sfb){const c=b(a);if(c)return c}return __c.su}WE(a){for(const b of this.Q8a){const c=b(a);if(c)return c}return __c.su}constructor(){this.Sfb=
[];this.Q8a=[];this.$S=void 0}};var $3;__c.QCa={Azb:function({gz:a,WE:b,$S:c}){if($3)return gsc($3,{gz:a,WE:b,$S:c}),$3;const d=new hsc;gsc(d,{gz:a,WE:b,$S:c});return $3=d}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/2ee06f86f4cdf14e.js.map