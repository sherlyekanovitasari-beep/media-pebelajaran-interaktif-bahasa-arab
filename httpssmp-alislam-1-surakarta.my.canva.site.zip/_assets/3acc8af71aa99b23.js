(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[42383],{

/***/ 375435:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.SOb={config:{language:"tr-TR",Of:{yMMMd:"d MMM yyyy",yMd:"dd.MM.yyyy",yMMM:"MMM yyyy"},dg:"Oca \u015eub Mar Nis May Haz Tem A\u011fu Eyl Eki Kas Ara".split(" "),eg:"Ocak \u015eubat Mart Nisan May\u0131s Haziran Temmuz A\u011fustos Eyl\u00fcl Ekim Kas\u0131m Aral\u0131k".split(" "),Ng:[{pattern:"dd *[./\\s-] *mm *[./\\s-] *yy",na:"yMd"},{pattern:"dd *[./\\s-] *mm *[./\\s-] *yyyy",na:"yMd"},{pattern:"yyyy *[./\\s-] *mm *[./\\s-] *dd",na:"yMd"},{pattern:"dd *[./\\s-] *mm",na:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/3acc8af71aa99b23.js.map