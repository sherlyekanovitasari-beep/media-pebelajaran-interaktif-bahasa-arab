(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[73823],{

/***/ 527623:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.FOb={config:{language:"fr-FR",Of:{yMMMd:"d MMM yyyy",yMd:"dd/MM/yyyy",yMMM:"MMM yyyy"},dg:"janv. f\u00e9vr. mars avr. mai juin juil. ao\u00fbt sept. oct. nov. d\u00e9c.".split(" "),eg:"janvier f\u00e9vrier mars avril mai juin juillet ao\u00fbt septembre octobre novembre d\u00e9cembre".split(" "),Ng:[{pattern:"yyyy *[./-] *mm *[./-] *dd",na:"yMd"},{pattern:"dd *[./-] *mm *[./-] *yy",na:"yMd"},{pattern:"dd *[./-] *mm *[./-] *yyyy",na:"yMd"},{pattern:"dd *[./-] *mm",na:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/3e9baf08760b7696.js.map