(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[59352],{

/***/ 874994:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(594352);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Egc=__webpack_require__(322594),Fgc=Egc.jsx,Ggc=Egc.jsxs;__c.j1=(0,__webpack_require__(205482).memo)(({header:a,body:b})=>Ggc("div",{children:[a!=null?Fgc(__c.Wu,{weight:"bold",size:"small",tagName:"div",lineClamp:0,tone:"primary",className:"_2V1T4g",alignment:"center",children:a}):void 0,b.map((c,d)=>Fgc(__c.Wu,{size:"small",tagName:"div",lineClamp:0,tone:"primary",className:"_2V1T4g",alignment:"center",children:c},d))]}));__c.k1=()=>({x:{get:a=>a.xa.title,direction:"horizontal",float:"bottom"},y:{get:a=>a.ta.title,direction:"vertical",float:"left"}});
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/42cb9dc382aa4534.js.map