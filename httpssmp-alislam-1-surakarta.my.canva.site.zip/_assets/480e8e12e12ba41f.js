(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[56325],{

/***/ 431793:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.yOb={config:{language:"es-CO",Of:{yMMMd:'d "de" MMM "de" yyyy',yMd:"d/M/yyyy",yMMM:'MMM "de" yyyy'},dg:"ene feb mar abr may jun jul ago sept oct nov dic".split(" "),eg:"enero febrero marzo abril mayo junio julio agosto septiembre octubre noviembre diciembre".split(" "),Ng:[{pattern:"dd *[/-] *mm *[/-] *yy",na:"yMd"},{pattern:"dd *[/-] *mm *[/-] *yyyy",na:"yMd"},{pattern:"dd *[/-] *mm",na:"yMd"},{pattern:"mmm de yyyy",na:"yMMM"},{pattern:"dd de mmm de yyyy",na:"yMMMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/480e8e12e12ba41f.js.map