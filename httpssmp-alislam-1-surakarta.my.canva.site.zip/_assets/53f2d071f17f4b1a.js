(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[92465],{

/***/ 246393:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Rjc;__c.Qjc=function(a,b={}){a=a.endsWith("\n")?a:a+"\n";return __c.Yh.create({...__c.HF,stream:__c.Yg.Kb().attrs({"font-size":4,...b}).lb(a).build()})};Rjc=a=>{switch(a){case "bulleted":return{"list-marker":"disc","list-level":1,"head-indent":1700};case "numbered":return{"list-marker":"decimal","list-level":1,"head-indent":1700};case "checked":case "none":return{"list-marker":"none","list-level":0,"head-indent":0};case void 0:return{};default:throw new __c.A(a);}};
__c.m2=a=>({decoration:a.Wd,direction:a.direction,"font-family":a.fontFamily,"font-style":a.fontStyle,"font-weight":a.fontWeight,tracking:a.letterSpacing,leading:a.lineHeight,...Rjc(a.Rg),"font-size":a.size,strikethrough:a.xj,"text-align":a.textAlign,"text-transform":a.textTransform});
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/53f2d071f17f4b1a.js.map