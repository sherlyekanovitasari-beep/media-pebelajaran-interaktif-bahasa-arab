(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[87444],{

/***/ 722536:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(337917);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var yoc,zoc,Aoc;yoc=function(a,b){a.lea.lY();return __c.joc(b,c=>a.lea.m5(c))};zoc=function(a,b){const c=b.TELEMETRY?.queuedOnSpanEndListener;b.TELEMETRY?.queuedOnSpanStartListener?.forEach(d=>a.tHa.push(d));c?.forEach(d=>a.sHa.push(d))};
Aoc=class{Nt(a){try{const b=yoc(this,[a]);for(const c of this.tHa)c(b)}catch(b){this.J.Ub(b)}this.Qm.Nt(a)}process(a){try{const b=yoc(this,a);for(const c of this.sHa)c(b)}catch(b){this.J.Ub(b)}this.Qm.process(a)}async flush(){await this.Qm.flush()}constructor(a,b,c=globalThis,d=new __c.qoc){this.J=a;this.Qm=b;this.global=c;this.lea=d;this.tHa=[];this.sHa=[];try{c.TELEMETRY={...c.TELEMETRY,addOnSpanStartListener:e=>{this.tHa.push(e)},addOnSpanEndListener:e=>{this.sHa.push(e)}},zoc(this,c)}catch(e){a.Ub(e)}}};
__c.xoc={};__c.xoc.ljb=Aoc;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/62ea5caaa6d5f2b5.js.map