(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[73640],{

/***/ 746008:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.sOb={config:{language:"en-AU",Of:{yMMMd:"d MMM yyyy",yMd:"dd/MM/yyyy",yMMM:"MMM yyyy"},dg:"Jan Feb Mar Apr May June July Aug Sept Oct Nov Dec".split(" "),eg:"January February March April May June July August September October November December".split(" "),Ng:[{pattern:"dd *[/-] *mm *[/-] *yy",na:"yMd"},{pattern:"dd *[/-] *mm *[/-] *yyyy",na:"yMd"},{pattern:"dd *[/-] *mm",na:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/6540eee50590d9c8.js.map