(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[16476],{

/***/ 424488:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var PCc=__webpack_require__(322594),m6=PCc.jsx,QCc=PCc.jsxs;var RCc=__webpack_require__(721226).PA;var SCc=__webpack_require__(205482).useId;var VCc,TCc,UCc;VCc=RCc(({element:a,Up:b,Gl:c})=>m6(b.role==="img"?TCc:UCc,{element:a,Up:b,Gl:c}));TCc=RCc(({Up:a})=>{const b=a.id,c=a.role,d=a.dK,e=a.name;a=__c.lx(Object.values(a.description).filter(f=>!!f).join(", "));return m6("div",{id:b,role:c,className:"_pFsfA","aria-roledescription":d,"aria-label":e,...a})});
UCc=RCc(({element:a,Up:b,Gl:c})=>{const d=SCc(),e=SCc(),f=b.id,g=b.role,h=b.dK,k=b.state;b=b.description;a=a.D.rb.first()?.text;return m6("div",{id:f,role:g,className:"_pFsfA","aria-roledescription":h,"aria-labelledBy":d?d:"","aria-describedBy":e,children:QCc("div",{role:"caption",children:[a&&m6("div",{id:d,children:m6(c,{text:a})}),m6("div",{id:e,children:Object.values({...k,...b}).filter(l=>!!l).join(", ")})]})})});__c.KQa={Bkb:VCc};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/713383bd176fa22f.js.map