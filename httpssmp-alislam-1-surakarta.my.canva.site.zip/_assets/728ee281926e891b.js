(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[3257],{

/***/ 846933:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.GOb={config:{language:"id-ID",Of:{yMMMd:"d MMM yyyy",yMd:"d/M/yyyy",yMMM:"MMM yyyy"},dg:"Jan Feb Mar Apr Mei Jun Jul Agu Sep Okt Nov Des".split(" "),eg:"Januari Februari Maret April Mei Juni Juli Agustus September Oktober November Desember".split(" "),Ng:[{pattern:"yyyy *[./-] *mm *[./-] *dd",na:"yMd"},{pattern:"dd *[./-] *mm *[./-] *yy",na:"yMd"},{pattern:"dd *[./-] *mm *[./-] *yyyy",na:"yMd"},{pattern:"dd *[./-] *mm",na:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/728ee281926e891b.js.map