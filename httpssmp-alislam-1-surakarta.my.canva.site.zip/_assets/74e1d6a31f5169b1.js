(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[32671],{

/***/ 493001:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(499352);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Lnc=function(a,{status:b,endTime:c,ref:d,url:e,file:f,type:g,span:h}){({gj:c}=h.end(b===0?"ok":"error",c));a.ec.track(__c.Uic,{source:"editor",success:b===0,resourceId:d.id,resourceType:Knc.Ga(g),version:d.version,url:e,height:f.height,width:f.width,quality:f.quality?__c.LS.Ga(f.quality):void 0,bk:f.bk,wg:f.wg,Zd:c()})},Knc=__c.cb(()=>[2,"RASTER",3,"VECTOR",4,"DESIGN",5,"FONT",6,"ELEMENT_GROUP"]);__c.Oqa=class{static create({ec:a,fb:b,LKb:c=.01,MKb:d=Math.random}){if(!(c<d()))return new __c.Oqa(a,b)}Zca({ref:a,file:b,type:c,startTime:d}){const e=b.url.startsWith("data:image/")?void 0:b.url,f=this.fb.ui("load_image",{startTime:d,attrs:new Map([["id",a.id],["version",a.version],["url",e],["height",b.height],["width",b.width],["quality",b.quality],["watermarked",b.bk],["spritesheet",b.wg]])});return{end:(g,h)=>Lnc(this,{status:g,endTime:h,ref:a,url:e,file:b,type:c,span:f})}}constructor(a,b){this.ec=
a;this.fb=b}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/74e1d6a31f5169b1.js.map