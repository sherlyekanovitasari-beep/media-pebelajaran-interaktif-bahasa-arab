(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[10468],{

/***/ 706140:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(258551);__web_req__(920725);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var dGc,eGc,fGc;dGc=__c.h_({D:__c.z0.OEb});eGc=__c.XZ()(()=>({createDefault(){return{data:{D:{},document:{}},P:{width:100,height:100}}}}));fGc=__c.IZ()(()=>({metadata:{type:"demo-4",name:__c.tb("vAIjvQ",[4])},D:__c.HZ(()=>{throw Error("Demo error");}),exports:{}}));__c.r_={Bh:eGc,Oo:fGc,Ch:dGc};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/74fd0928b2c6d0ec.js.map