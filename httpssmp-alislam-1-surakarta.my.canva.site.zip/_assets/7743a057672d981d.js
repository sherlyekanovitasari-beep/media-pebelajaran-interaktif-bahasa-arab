(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[36931],{

/***/ 138527:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(499352);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var lFc,oFc,nFc,mFc;lFc=function(a,{success:b,endTime:c,fill:d,file:e,url:f,ELb:g,span:h}){({gj:c}=h.end(b?"ok":"error",c));a.ec.track(__c.Uic,{source:"editor",success:b,resourceId:d.video,resourceType:g,url:f,height:e.height,width:e.width,quality:e.quality,bk:e.bk,Zd:c()})};
oFc=class{MNb({fill:a,startTime:b,file:c}){if(!this.fta.has(a)&&!this.yfb.has(a)){var d=c.url?.startsWith("data:")||c.url?.startsWith("blob:")?void 0:c.url,e=c.container&&mFc(c.container),f=this.fb.ui("load_video",{startTime:b,attrs:new Map([["id",a.video],["url",nFc(d)],["height",c.height],["width",c.width],["quality",c.quality],["container",e],["watermarked",c.bk]])});this.fta.set(a,{end:(g,h)=>lFc(this,{success:g,endTime:h,fill:a,file:c,url:d,ELb:e,span:f})})}}QYa({success:a,fill:b,endTime:c}){const d=
this.fta.get(b);d&&(d.end(a,c),this.fta.delete(b),this.yfb.add(b))}constructor(a,b){this.ec=a;this.fb=b;this.fta=new WeakMap;this.yfb=new WeakSet}};nFc=a=>{if(!a)return a;let b;try{b=new URL(a)}catch(c){return a}b.search="";return b.toString()};mFc=a=>{switch(a){case 1:return"MP4";case 2:return"GIF";case 4:return"LOTTIE";case 3:return"WEBM";default:throw new __c.A(a);}};__c.QSa={};__c.QSa.Ykb=oFc;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/7743a057672d981d.js.map