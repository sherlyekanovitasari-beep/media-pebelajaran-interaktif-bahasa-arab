(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[61192],{

/***/ 10004:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var WCc;
WCc=class{role(a){return this.innerText(a)?"group":"img"}innerText(a){a=a.rb.first()?.text;return a?.stream.isEmpty?void 0:a}name(a){const b=a.Xa;return b&&b.text?b.text:(a=this.innerText(a))?__c.cV(a):__c.K("uChMHQ")}description(a,b){var c=b.ob.first()?.fill;c=(c=c?.color??c?.$a.ref)?this.MD.p_a(c):void 0;b=__c.DB(b)?(b=(b=b.rb.last()?.text)?__c.cV(b):void 0)?__c.tb("NmV2Uw",[b]):void 0:void 0;return{...a.description,color:c,ewa:b}}constructor(a){this.MD=a;this.createNode=(b,c)=>{c=c.D;return{...b,role:this.role(c),
name:this.name(c),description:this.description(b,c)}}}};__c.JQa={};__c.JQa.Akb=WCc;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/777e5b82dfd123c3.js.map