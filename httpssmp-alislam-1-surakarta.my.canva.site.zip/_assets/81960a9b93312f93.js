(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[41990],{

/***/ 726928:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var pFc=__webpack_require__(186901).sH;var qFc=class{static G(a){__c.L(a,{M_a:pFc.ref})}constructor(){this.M_a=(qFc.G(this),void 0)}};var rFc=class{constructor(){this.sources=new WeakMap}};var sFc=class{static G(a){__c.L(a,{Bw:pFc.shallow})}register(a,b){this.Bw.has(a)||this.Bw.set(a,b)}get(a){return this.Bw.get(a)}constructor(){this.Bw=(sFc.G(this),new Map)}};var tFc=class{constructor(a){this.BFa=a}};__c.aTa={Hzb:function(){const a=new qFc,b=new rFc,c=new sFc;return{Gea:a,$gc:new tFc(b),Iea:c}}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/81960a9b93312f93.js.map