(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[58095],{

/***/ 793225:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var l$c=__webpack_require__(322594).jsx;var m$c=__webpack_require__(205482).memo;__c.m6b={yya:function({dj:a}){return m$c(function({height:b,page:c,width:d,fit:e}){return l$c(a,{page:c,Sb:d,uc:b,fit:e,Sf:!1,Kq:"static-with-placeholder-fallback",rd:__c.$U})})}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/81f9a9ddbb335808.js.map