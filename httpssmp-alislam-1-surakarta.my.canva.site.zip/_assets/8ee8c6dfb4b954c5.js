(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[44242],{

/***/ 104398:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.Ync=class{process(a){try{for(const b of a){const c=`${b.name}-${b.spanContext().spanId}`;this.performance.mark(`${c}-start`,{startTime:Math.max(b.startTime,0)});this.performance.mark(`${c}-end`,{startTime:b.endTime});const d=b.aborted,e=b.status==="error",f=b.Px==="event";let g="";__c.iI(b)?g="UOP: ":f&&(g="Event: ");e?g=`[Error] ${g}`:d&&(g=`[Aborted] ${g}`);this.performance.measure(`\ud83d\udd2d ${g}${b.name}`,{start:Math.max(b.startTime,0),end:b.Px==="event"?(b.endTime??0)+.5:b.endTime})}}catch(b){this.J.Ub(b,
{Je:`Failed to export the span buffer from ${__c.Ync.name}`,extra:new Map(__c.nI(a))})}finally{this.Qm?.process(a)}}Nt(a){this.Qm?.Nt(a)}async flush(){return this.Qm?.flush()}constructor(a,b,c=self.performance){this.J=a;this.Qm=b;this.performance=c}};__c.Znc={};__c.Znc.mua=__c.Ync;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/8ee8c6dfb4b954c5.js.map