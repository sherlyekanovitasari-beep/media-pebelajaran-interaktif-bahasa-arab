(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[97078],{

/***/ 201794:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.wOb={config:{language:"en-PH",Of:{yMMMd:"MMM d, yyyy",yMd:"M/d/yyyy",yMMM:"MMM yyyy"},dg:"Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" "),eg:"January February March April May June July August September October November December".split(" "),Ng:[{pattern:"mm *[/-] *dd *[/-] *yy",na:"yMd"},{pattern:"mm *[/-] *dd *[/-] *yyyy",na:"yMd"},{pattern:"mm *[/-] *dd",na:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/929564421da09a04.js.map