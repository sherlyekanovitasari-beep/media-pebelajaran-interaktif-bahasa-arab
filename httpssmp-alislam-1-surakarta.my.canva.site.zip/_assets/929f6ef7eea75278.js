(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[26050],{

/***/ 875986:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.tOb={config:{language:"en-CA",Of:{yMMMd:"MMM d, yyyy",yMd:"yyyy-MM-dd",yMMM:"MMMM yyyy"},dg:"Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" "),eg:"January February March April May June July August September October November December".split(" "),Ng:[{pattern:"yy *[/-] *mm *[/-] *dd",na:"yMd"},{pattern:"dd *[/-] *mm *[/-] *yyyy",na:"yMd"},{pattern:"mm *[/-] *dd",na:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/929f6ef7eea75278.js.map