(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[15670],{

/***/ 666558:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var mrc=__webpack_require__(205482).createRef;var nrc=__webpack_require__(186901),orc=nrc.EW,U3=nrc.sH;var prc;
prc=class{static G(a){__c.L(a,{E1:U3.ref,fva:U3.ref,enabled:orc,open:orc,key:U3.ref,LD:U3.ref,position:orc,content:U3.ref,placement:U3.ref,arrow:U3.ref})}get enabled(){return!this.C.fi.FP.disabled}get open(){return this.fva&&this.enabled&&this.Swb()}set open(a){this.fva=a}set position(a){this.LD=a}get position(){const a=this.LD,b=this.C.padding,c=this.da?.get()??1;return{left:c*((this.ce?a.left-this.C.width:a.left)+b.left),top:c*(a.top+b.top),width:c*a.width,height:c*a.height}}constructor(a,b,c,d=
__c.Dv.direction===2){this.C=a;this.da=b;this.Swb=c;this.ce=d;this.E1=(prc.G(this),mrc());this.fva=!1;this.key=void 0;this.LD={top:0,left:0,width:0,height:0};this.content="";this.placement="bottom-center";this.arrow=!0;this.le=0}};__c.Bv={};__c.Bv.IPa=prc;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/967c0ff565f5c962.js.map