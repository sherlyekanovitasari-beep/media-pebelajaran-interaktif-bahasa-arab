(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[77112],{

/***/ 914020:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.JOb={config:{language:"ko-KR",Of:{yMMMd:"yyyy\ub144 MMM d\uc77c",yMd:"yyyy. M. d.",yMMM:"yyyy\ub144 MMM"},dg:"1\uc6d4 2\uc6d4 3\uc6d4 4\uc6d4 5\uc6d4 6\uc6d4 7\uc6d4 8\uc6d4 9\uc6d4 10\uc6d4 11\uc6d4 12\uc6d4".split(" "),eg:"1\uc6d4 2\uc6d4 3\uc6d4 4\uc6d4 5\uc6d4 6\uc6d4 7\uc6d4 8\uc6d4 9\uc6d4 10\uc6d4 11\uc6d4 12\uc6d4".split(" "),Ng:[{pattern:"yy *[./\\s-] *mm *[./\\s-] *dd[.]?",na:"yMd"},{pattern:"yy *[.\ub144/\\s-] *mm *[.\uc6d4/\\s-] *dd[.\uc77c]?",na:"yMMMd"},{pattern:"yyyy *[.\\s] *mm *[.\\s] *dd[.]?",
na:"yMd"},{pattern:"yyyy *[.\ub144\\s] *mm *[.\uc6d4\\s] *dd[.\uc77c]?",na:"yMMMd"},{pattern:"dd *[./\\s-] *mm *[./\\s-] *yyyy",na:"yMd"},{pattern:"dd *[./\uc77c\\s-] *mm *[\uc6d4./\\s-] *yyyy[\ub144]?",na:"yMMMd"},{pattern:"mm *[./\\s-] *dd[.]?",na:"yMd"},{pattern:"mm *[.\uc6d4/\\s-] *dd[.\uc77c]?",na:"yMMMd"},{pattern:"yyyy\ub144 *mmm",na:"yMMM"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/9980382e47b0c902.js.map