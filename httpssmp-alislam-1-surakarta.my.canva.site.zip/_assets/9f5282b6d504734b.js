(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[98259],{

/***/ 580825:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(258551);__web_req__(586838);__web_req__(920725);__web_req__(246393);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var NFc=__webpack_require__(322594).jsx;var OFc=__webpack_require__(721226).PA;var PFc,QFc,RFc;PFc=__c.h_({document:__c.g_({...__c.W0(1),...__c.X0(2),n1a:__c.z0.ATa(3)}),D:{kd:__c.z0.RGb()}});QFc=__c.XZ()(()=>({createDefault(){return{data:{document:{n1a:!1,kd:"#000000",Vv:__c.Y0({lineHeight:1250,size:12,textAlign:"center"})},D:{kd:void 0}},P:{width:12,height:15}}}}));
RFc=__c.IZ()(()=>({metadata:{type:"demo-10",name:__c.tb("vAIjvQ",[10])},D:__c.HZ(OFc(({data:{document:a,D:b},De:c,Ci:{page:d}})=>{c=c.ek;var e=__c.Yh.create;b=__c.Yg.Kb().attrs({...__c.m2(a.Vv),color:b.kd??a.kd});var f=b.lb;a=a.n1a;const g=(d.getIndex()+1).toString();return NFc("div",{className:"LjWkdQ",children:NFc(c,{text:e.call(__c.Yh,{...__c.HF,stream:f.call(b,a?d.title?`Page ${g}:\n${d.title}`:`Page ${g}`:g).zq().build()})})})})),exports:{}}));__c.x_={Bh:QFc,Oo:RFc,Ch:PFc};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/9f5282b6d504734b.js.map