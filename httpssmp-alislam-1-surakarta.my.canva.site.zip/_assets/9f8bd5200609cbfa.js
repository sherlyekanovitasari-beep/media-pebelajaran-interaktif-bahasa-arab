(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[97668],{

/***/ 794336:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Jjc=__webpack_require__(186901).EW;__c.l2=class{static G(a){__c.L(a,{step:Jjc})}get kind(){return"point"}clone({wc:a=this.wc,Hc:b=this.Hc,Fh:c=this.Fh,be:d=this.be,inverse:e=this.inverse}){return new __c.l2({wc:a,Hc:b,Fh:c,be:d,inverse:e})}snapshot(){const a=this.wc(),b=this.Hc();return new __c.l2({wc:()=>a,Hc:()=>b,Fh:this.Fh,be:this.be,inverse:this.inverse})}get(a){const b=this.wc();var c=b.indexOf(a);c=this.inverse?b.length-1-c:c;__c.u(c!==-1,`value ${a} must exist in domain`);const [d,e]=this.Hc();a=b.length===1?.5:this.Fh();return d+
(a*this.step+c*this.step)*Math.sign(e-d)}get step(){const a=this.wc().length+2*this.Fh(),[b,c]=this.Hc();return Math.abs(c-b)/Math.max(a-1,1)}Bha(a,b,c){__c.u(a.index!==b.index);const d=this.Fh(),e=(b.center-a.center)/(b.index-a.index);return[a.center-(d+a.index)*e,b.center+(d+c-b.index-1)*e]}Aha(a,b,c){const d=this.Fh();return[b,a.center+(a.center-b)/(a.index+d)*(d+c-a.index-1)]}zha(a,b,c){const d=this.Fh();return[a.center-(b-a.center)/(c-a.index-1+d)*(d+a.index),b]}constructor({wc:a,Hc:b,Fh:c,be:d,
inverse:e=!1}){__c.l2.G(this);this.wc=a;this.Hc=b;this.Fh=c;this.be=d;this.inverse=e}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/9f8bd5200609cbfa.js.map