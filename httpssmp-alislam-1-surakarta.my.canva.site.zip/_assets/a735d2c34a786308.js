(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[87001],{

/***/ 619313:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(990971);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Vmc;Vmc=function(a,b){a=__c.zZ(a);return{fixed:a.fixed*b,oh:a.oh*b}};__c.c3=class extends __c.kac{nn(a,b){const c=this.ea.rect,d=this.ea.velocity,e=a.random(),f=a.random();if(d)switch(d.type){case "relative":b.velocity=b.velocity.add(__c.$Y(d.x.min,d.x.max,e),__c.$Y(d.y.min,d.y.max,f));break;case "random":b.velocity=b.velocity.add(__c.vZ(d.x,a),__c.vZ(d.y,a))}return{x:__c.AZ(c.x,Vmc(c.width,e)),y:__c.AZ(c.y,Vmc(c.height,f)),offset:void 0}}constructor(a){super(a);this.ea=a}};
__c.Wmc=class{nn(a){return{rect:this.ea.rect&&__c.jac(this.ea.rect,a)}}Dv(a,b,c,d){c=this.ea.image;c instanceof HTMLImageElement&&!c.complete||(a=a.Ci,d=d.rect,__c.yZ(a,b),a.globalAlpha*=b.color.a,d!=null?a.drawImage(c,d.x,d.y,d.width,d.height):a.drawImage(c,c.width*-.5,c.height*-.5),b.Qpa=!0)}constructor(a){this.ea=a}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/a735d2c34a786308.js.map