(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[4689],{

/***/ 797279:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Q$b,P$b;__c.O$b=function(a,b){return __c.Yh.create({...__c.HF,stream:__c.Yg.Kb().attrs({"font-size":a.fontSize,"font-weight":a.fontWeight,"font-style":a.fontStyle,"font-family":a.So}).lb(`${b}\n`).build()})};
Q$b=class{wya(a,b){const c=a.stream.hh(0),{fontSize:d,fontFamily:e,fontWeight:f,fontStyle:g}={fontSize:c["font-size"]??__c.pg.Tb["font-size"],fontFamily:c["font-family"]||__c.pg.Tb["font-family"],fontWeight:c["font-weight"]||__c.pg.Tb["font-weight"],fontStyle:c["font-style"]||__c.pg.Tb["font-style"]};return`${a.stream.Z.substring(0,a.stream.charLength-1)}`+`.${d.toFixed(1)}`+`.${e}`+`.${__c.Gn(f)}`+`.${g}`+`.${b.toFixed(1)}`}N0(a,b){if(a.stream.charLength===1||b===0)var c=[];else{{c=this.cache;const d=
c.wya(a,b),e=c.cache.get(d);e!=null?c=e:(a=c.N0(a,b),c.cache.set(d,a),c=a)}}return c}constructor(a){this.Bf=a;this.cache=new P$b((b,c)=>{if(b.stream.charLength===1||c===0)var d=[];else{b=__c.Jp(this.Bf,b.Cj(this.Oc),1,"em-square");try{d=b.N0(c)}finally{b.destroy()}}return d},(b,c)=>this.wya(b,c));this.Oc={styles:new Map,version:0}}};P$b=class{constructor(a,b){this.N0=a;this.wya=b;this.cache=new Map}};__c.Ev={};__c.Ev.Gib=Q$b;__c.Ev.Sbc=__c.O$b;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/b84678825c86bcb5.js.map