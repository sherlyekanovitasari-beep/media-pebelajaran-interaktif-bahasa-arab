(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[96700],{

/***/ 181876:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var jFc=__webpack_require__(322594).jsx;var kFc=__webpack_require__(721226).PA;__webpack_require__(205482);__c.NSa={Ukb:kFc(({element:a,Up:b,Gl:c})=>{const d=b.id,e=b.role,f=b.name,g=b.dK;b=__c.lx(__c.mx(Object.values({...b.state,...b.description})));return jFc("div",{id:d,role:e,"aria-label":f,"aria-roledescription":g,...b,className:"_pFsfA",children:jFc(c,{text:a.D.text})})})};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/b989fdbe6e187afb.js.map