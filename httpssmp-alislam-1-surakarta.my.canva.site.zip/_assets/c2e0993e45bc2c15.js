(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[97337],{

/***/ 655404:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(91197);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var d9b=__webpack_require__(322594).jsx;var e9b=__webpack_require__,f9b=e9b(802496),g9b=e9b.n_x(f9b);var h9b=__webpack_require__(205482).Component;var i9b=__webpack_require__(186901),j9b=i9b.m3,k9b=i9b.mJ;var l9b=__webpack_require__(269018)._;var m9b,n9b,o9b=class extends h9b{componentDidMount(){__c.gc(this,[k9b(()=>[this.props.animationData,this.props.Sc],()=>{const a=this.props.animationData,b=this.props.Sc,c=this.props.yD;a&&this.loadAnimation(a,b,c)},{fireImmediately:!0,equals:j9b.shallow}),k9b(()=>this.props.yD,a=>{this.bo&&this.bo.goToAndStop(a*1E3)},{fireImmediately:!0})])}componentWillUnmount(){this.bo?.destroy()}render(){const a=this.props.Xa,{ariaHidden:b,ariaLabel:c}=__c.SU(a);return d9b("div",{className:"_8i6R0w",ref:this.F0,
role:a?"img":void 0,"aria-label":c,"aria-hidden":b})}loadAnimation(a,b,c){const d=this.F0.current;d&&(a=JSON.parse(JSON.stringify(a)),__c.b9b(a,b),this.bo&&this.bo.destroy(),this.bo=g9b().loadAnimation({autoplay:!1,animationData:a,container:d,renderer:"svg"}),b=d.getElementsByTagName("svg")[0])&&(b.style.transform==="translate3d(0px, 0px, 0px)"&&(b.style.transform=""),this.bo.goToAndStop(c*1E3))}constructor(...a){super(...a);this.F0=__c.au()}};({c:[n9b,m9b]}=l9b(o9b,[],[__c.pc],h9b));m9b();
__c.uTb={};__c.uTb.Zkb=n9b;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/c2e0993e45bc2c15.js.map