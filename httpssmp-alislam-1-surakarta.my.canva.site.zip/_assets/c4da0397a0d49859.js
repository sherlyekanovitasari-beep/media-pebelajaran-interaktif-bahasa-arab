(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[57702],{

/***/ 310100:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var h1,Dgc,f1,Cgc;
__c.g1=function(a){const b=({Zcb:c=!1,children:d})=>{const e=ygc(),f=zgc(null);Agc(()=>Bgc(()=>{const {width:g,height:h,top:k=0,left:l=0}=a(),m=f.current;m&&(m.setAttribute("width",g.toString()),m.setAttribute("height",h.toString()),m.setAttribute("x",l.toString()),m.setAttribute("y",k.toString()))}),[]);return Cgc(Dgc,{children:[!c&&f1("clipPath",{id:e,children:f1("rect",{ref:f})}),f1("g",{clipPath:c?void 0:`url(#${e})`,children:d})]})};b.displayName=a.name!=null?`ClippingContainer(${a.name})`:"ClippingContainer";
return b};h1=__webpack_require__(322594);Dgc=h1.Fragment;f1=h1.jsx;Cgc=h1.jsxs;var i1=__webpack_require__(205482),Agc=i1.useEffect,ygc=i1.useId,zgc=i1.useRef;var Bgc=__webpack_require__(186901).fm;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/c4da0397a0d49859.js.map