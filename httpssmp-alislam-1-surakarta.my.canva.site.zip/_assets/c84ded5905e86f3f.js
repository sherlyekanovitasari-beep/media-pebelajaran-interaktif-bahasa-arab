(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[22869],{

/***/ 366723:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var TBc=function(a){if(!a)return"";a=a.filter(b=>!!b);return a.length>0?a.join(" "):""},UBc=__webpack_require__(322594),f6=UBc.jsx,VBc=UBc.jsxs;var WBc=__webpack_require__(721226).PA;var g6=__webpack_require__(205482).useId;var ZBc,XBc,YBc;ZBc=WBc(({element:a,Up:b,Gl:c})=>f6(b.role==="img"?XBc:YBc,{element:a,Up:b,Gl:c}));XBc=WBc(({Up:a})=>{const b=a.id,c=a.role,d=a.dK,e=a.name;a=__c.lx(__c.mx(Object.values({...a.state,...a.description})));return f6("div",{id:b,role:c,className:"_pFsfA","aria-roledescription":d,"aria-label":e,...a})});
YBc=WBc(({element:a,Up:b,Gl:c})=>{const d=g6(),e=g6(),f=g6(),g=g6(),h=b.id,k=b.role,l=b.dK;var m=b.description;b=b.state;a=a.D.rb.first()?.text;const n=m.pD,p=m.HB,q=TBc([n?d:void 0,g,p?e:void 0]);m={color:m.color,nWa:m.nWa,weight:m.weight};return f6("div",{id:h,role:k,className:"_pFsfA","aria-roledescription":l,"aria-describedby":q,"aria-labelledby":f,children:VBc("div",{role:"caption",children:[n&&f6("span",{id:d,children:n}),a&&f6("div",{id:f,children:f6(c,{text:a})}),p&&f6("span",{id:e,children:p}),
f6("div",{id:g,children:f6("p",{children:__c.mx(Object.values({...b,...m}))})})]})})});__c.iMa={Mjb:ZBc};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/c84ded5905e86f3f.js.map