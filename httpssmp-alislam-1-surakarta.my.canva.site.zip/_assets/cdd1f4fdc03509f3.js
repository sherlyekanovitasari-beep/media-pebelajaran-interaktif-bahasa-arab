(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[65309],{

/***/ 247793:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.rOb={config:{language:"de-DE",Of:{yMMMd:"d. MMM yyyy",yMd:"d.M.yyyy",yMMM:"MMM yyyy"},dg:"Jan. Feb. M\u00e4rz Apr. Mai Juni Juli Aug. Sept. Okt. Nov. Dez.".split(" "),eg:"Januar Februar M\u00e4rz April Mai Juni Juli August September Oktober November Dezember".split(" "),Ng:[{pattern:"dd *[./-] *mm *[./-] *yy",na:"yMd"},{pattern:"dd *[./-] *mm *[./-] *yyyy",na:"yMd"},{pattern:"dd *[./-]? *mmm *[./-]? *yyyy",na:"yMMMd"},{pattern:"yyyy *[./-] *mm *[./-] *dd",na:"yMd"},{pattern:"dd *[./-] *mm",na:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/cdd1f4fdc03509f3.js.map