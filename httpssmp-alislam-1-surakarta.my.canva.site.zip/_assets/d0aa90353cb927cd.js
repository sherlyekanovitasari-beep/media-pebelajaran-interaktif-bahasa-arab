(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[41498],{

/***/ 667682:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(367659);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var bPc={je:"live_audience_panel_toggled",Af(a){return __c.Sn({presenting_context:a.Nd==null?void 0:__c.uH(a.Nd),session_id:a.sessionId,source:a.source,action:a.action,design_id:a.bi,doctype_id:a.rn,category_id:a.Jc})}},cPc=__webpack_require__(186901),dPc=cPc.sH,ePc=cPc.XI;var fPc;
fPc=class{static G(a){__c.L(a,{Tp:dPc.ref,open:ePc.bound,close:ePc.bound,toggle:ePc.bound})}get xd(){return this.Tp}open(){this.Tp||(this.Tp=!0,this.la.track(bPc,{sessionId:this.Dn.state.session?.id,source:"fullscreen_mode",action:"show",bi:""}))}close(){this.Tp&&(this.Tp=!1,this.la.track(bPc,{sessionId:this.Dn.state.session?.id,source:"fullscreen_mode",action:"hide",bi:""}))}toggle(){this.Tp=!this.Tp;this.la.track(bPc,{sessionId:this.Dn.state.session?.id,source:"fullscreen_mode",action:this.Tp?"show":
"hide",bi:""})}constructor(a,b){this.Dn=a;this.la=b;this.Tp=(fPc.G(this),void 0);this.Tp=!!this.Dn.state.session}};__c.o0a={};__c.o0a.oib=fPc;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/d0aa90353cb927cd.js.map