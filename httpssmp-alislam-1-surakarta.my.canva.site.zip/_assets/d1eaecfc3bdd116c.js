(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[7923],{

/***/ 539667:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.MOb={config:{language:"pl-PL",Of:{yMMMd:"d MMM yyyy",yMd:"d.MM.yyyy",yMMM:"MMM yyyy"},dg:"sty lut mar kwi maj cze lip sie wrz pa\u017a lis gru".split(" "),eg:"stycznia lutego marca kwietnia maja czerwca lipca sierpnia wrze\u015bnia pa\u017adziernika listopada grudnia".split(" "),Ng:[{pattern:"yyyy *[./\\s-] *mm *[./\\s-] *dd",na:"yMd"},{pattern:"yy *[./\\s-] *mm *[./\\s-] *dd",na:"yMd"},{pattern:"dd *[./\\s-] *mm *[./\\s-] *yyyy",na:"yMd"},{pattern:"mm *[./\\s-] *dd",na:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/d1eaecfc3bdd116c.js.map