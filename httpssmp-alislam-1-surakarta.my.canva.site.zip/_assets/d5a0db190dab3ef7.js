(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[62600],{

/***/ 793252:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.QOb={config:{language:"sv-SE",Of:{yMMMd:"d MMM yyyy",yMd:"yyyy-MM-dd",yMMM:"MMM yyyy"},dg:"jan. feb. mars apr. maj juni juli aug. sep. okt. nov. dec.".split(" "),eg:"januari februari mars april maj juni juli augusti september oktober november december".split(" "),Ng:[{pattern:"yyyy *[./\\s-] *mm *[./\\s-] *dd",na:"yMd"},{pattern:"yy *[./\\s-] *mm *[./\\s-] *dd",na:"yMd"},{pattern:"dd *[./\\s-] *mm *[./\\s-] *yyyy",na:"yMd"},{pattern:"mm *[./\\s-] *dd",na:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/d5a0db190dab3ef7.js.map