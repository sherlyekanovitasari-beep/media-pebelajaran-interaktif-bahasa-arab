(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[27648],{

/***/ 456150:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var bFc=__webpack_require__(322594),P6=bFc.jsx,cFc=bFc.jsxs;var dFc=__webpack_require__(721226).PA;__webpack_require__(205482);var hFc,fFc,gFc,eFc;
hFc=dFc(({element:a,Up:b,MD:c,Gl:d})=>{const e=b.id,f=b.name,g=b.role;var h=b.description;b=__c.mx(Object.values(b.state),Object.values(h));b=__c.lx(b);const k=a.D,l=k.layout.rows.toArray();a=k.layout.direction===2?"rtl":"ltr";h=__c.Km(k);const m=__c.Jm(k),n=__c.Yla(k);return cFc("table",{id:e,role:g,dir:a,className:"_pFsfA",...b,children:[f&&P6("caption",{children:f}),P6(eFc,{}),P6("tbody",{children:h.map((p,q)=>P6("tr",{children:p.map((r,t)=>P6(fFc,{table:k,Mg:r?.Mg,tob:m,rowIndex:q,npb:t,children:(v,
w)=>P6(gFc,{Ta:v,sob:w,MD:c,Gl:d})},n(q,t)))},k.layout.rows.Pr(l[q])))})]})});fFc=({table:a,Mg:b,tob:c,rowIndex:d,npb:e,children:f})=>(c=(a=b!=null&&a.cells.get(b))&&c.get(a))&&c.rows[0]===d&&c.columns[0]===e?f(a,c):null;gFc=dFc(({Ta:a,sob:b,MD:c,Gl:d})=>{const e=a.content.text,f=e.stream.isEmpty;c=(a=a.fill.color??a.fill.$a.ref)?c.p_a(a):void 0;c=__c.lx(c);return P6("td",{rowSpan:b.rows.length,colSpan:b.columns.length,...c,children:f?__c.K("ecweuA"):P6(d,{text:e})})});eFc=()=>P6("thead",{});
__c.h4b={Skb:hFc};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/d5ba9c990e81c703.js.map