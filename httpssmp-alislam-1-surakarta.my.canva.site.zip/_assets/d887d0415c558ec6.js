(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[72397],{

/***/ 856303:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var W2=Math.PI/5,X2=Math.cos(W2),Y2=Math.sin(W2),Hmc=Math.cos(W2/2),Imc=Math.sin(W2/2),Jmc=Math.atan(Math.PI/2-2*W2);__c.Kmc={[1]:function({x:a,y:b},c){const d=c/2;return["M",a+d,b,"a",d,d,0,0,0,-c,0,"a",d,d,0,0,0,c,0,"Z"].join(" ")},[2]:function({x:a,y:b},c,d){c/=2;d=d||0;return["M",a+c,b+c-d,"L",a+c,b-c+d,"A",d,d,0,0,0,a+c-d,b-c,"L",a-c+d,b-c,"A",d,d,0,0,0,a-c,b-c+d,"L",a-c,b+c-d,"A",d,d,0,0,0,a-c+d,b+c,"L",a+c-d,b+c,"A",d,d,0,0,0,a+c,b+c-d,"Z"].join(" ")},[3]:function({x:a,y:b},c){c/=2;return["M",a,b+c,"L",a+c,b,"L",a,b-c,"L",a-c,b,"Z"].join(" ")},[4]:function({x:a,y:b},c){c/=2;return["M",a,b-c,"L",a-c,b+c,"L",
a+c,b+c,"Z"].join(" ")},[5]:function({x:a,y:b},c){c/=2;const d=2*c*Y2,e=c-d*Y2,f=d*X2,g=Math.sqrt(e*e+Math.pow(Jmc*d*Y2,2));return["M",a,b-c,"L",a-Y2*g,b-X2*g,"L",a-f,b-e,"L",a-Hmc*g,b+Imc*g,"L",a-d/2,b+c*X2,"L",a,b+g,"L",a+d/2,b+c*X2,"L",a+Hmc*g,b+Imc*g,"L",a+f,b-e,"L",a+Y2*g,b-X2*g,"Z"].join(" ")}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/d887d0415c558ec6.js.map