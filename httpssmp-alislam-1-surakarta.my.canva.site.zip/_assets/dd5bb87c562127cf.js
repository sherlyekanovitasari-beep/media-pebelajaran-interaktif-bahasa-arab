(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[82433],{

/***/ 529188:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(325814);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var jnc=__webpack_require__(322594).jsx;__webpack_require__(205482);var knc;knc=a=>jnc(__c.a3,{buttons:[{className:"BB6Tuw"}],EM:a.description,open:!0,title:a.title});__c.$8b={mib:()=>{var a=__c.K("guY7ag"),b=__c.K("eUGHYg");return jnc(knc,{title:a,description:b})},zib:()=>jnc(knc,{title:__c.K("guY7ag"),description:__c.K("idpShQ")}),SUb:knc};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/dd5bb87c562127cf.js.map