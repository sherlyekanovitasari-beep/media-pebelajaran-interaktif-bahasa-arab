(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[78444],{

/***/ 555100:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var cCc;cCc=class{role(a){return a.fill.video.ref?"figure":"img"}name(a,b){const c=!!b.fill.video.ref||!!b.fill.image.ref,d=b.fill.video.ref?.Xa?.text??b.fill.image.ref?.Xa?.text;return c&&d?d:c?a.name:b.Xa?.text}state(a,b){return{...a.state,autoplay:b.fill.video.ref?.autoplay?__c.K("jFg4Bw"):void 0}}constructor(){this.createNode=(a,b)=>{b=b.D;return{...a,role:this.role(b),name:this.name(a,b),state:this.state(a,b)}}}};__c.EOa={};__c.EOa.pkb=cCc;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/e3a997557dd5e97e.js.map