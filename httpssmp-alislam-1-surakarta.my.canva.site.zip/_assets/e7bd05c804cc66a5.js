(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[12692],{

/***/ 219376:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.qOb={config:{language:"cs-CZ",Of:{yMMMd:"d. MMMM yyyy",yMd:"d. M. yyyy",yMMM:"MMMM yyyy"},dg:"led \u00fano b\u0159e dub kv\u011b \u010dvn \u010dvc srp z\u00e1\u0159 \u0159\u00edj lis pro".split(" "),eg:"ledna \u00fanora b\u0159ezna dubna kv\u011btna \u010dervna \u010dervence srpna z\u00e1\u0159\u00ed \u0159\u00edjna listopadu prosince".split(" "),Ng:[{pattern:"dd *[./-] *mm *[./-] *yy",na:"yMd"},{pattern:"dd *[./-] *mm *[./-] *yyyy",na:"yMd"},{pattern:"dd *[./-]? *mmmm *[./-]? *yyyy",na:"yMMMd"},
{pattern:"yyyy *[./-] *mm *[./-] *dd",na:"yMd"},{pattern:"dd *[./-] *mm",na:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/e7bd05c804cc66a5.js.map