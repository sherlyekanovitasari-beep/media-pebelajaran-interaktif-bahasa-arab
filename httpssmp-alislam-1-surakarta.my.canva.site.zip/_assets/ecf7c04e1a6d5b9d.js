(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[70245],{

/***/ 575567:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var aFc;aFc=class{name(a){return a.Xa?.text}role(){return"table"}constructor(){this.createNode=(a,b)=>({...a,name:this.name(b.D),role:this.role()})}};__c.g4b={};__c.g4b.Rkb=aFc;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/ecf7c04e1a6d5b9d.js.map