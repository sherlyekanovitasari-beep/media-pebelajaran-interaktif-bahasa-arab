(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[9677],{

/***/ 903874:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.l1=function(a){switch(a.type){case "STACKED_COLUMN":case "STACKED_ROW":case "STACKED_AREA":return a.md;case "GROUPED_COLUMN":case "GROUPED_ROW":case "PIE":case "DONUT":case "LINE":case "SCATTERPLOT":case "BUBBLEPLOT":case "DOTPLOT":case "GROUPED_DOTPLOT":case "PACKED_CIRCLES":case "TREEMAP":case "BAR_RACE":case "HISTOGRAM":case "RADAR":case "POPULATION_PYRAMID":case "FUNNEL":case "DUMBBELL":case "LOLLIPOP":case "SUNBURST":case "TIME_SERIES":case "PROGRESS":case "PICTOGRAM":break;default:throw new __c.A(a);
}};__c.m1=function(a){if(a?.type==="live-sheets")return"live_linked_sheet"};__c.n1=function(a){const b=Math.max(...a.map(({actualBoundingBoxAscent:c})=>c));a=Math.max(...a.map(({actualBoundingBoxDescent:c})=>c));return{AF:b,kea:b+a}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/f2776369a575e95f.js.map