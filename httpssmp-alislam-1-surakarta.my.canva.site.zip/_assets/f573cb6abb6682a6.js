(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[12232],{

/***/ 240352:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.UOb={config:{language:"zh-CN",Of:{yMMMd:"yyyy\u5e74M\u6708d\u65e5",yMd:"yyyy/M/d",yMMM:"yyyy\u5e74M\u6708"},dg:"1\u6708 2\u6708 3\u6708 4\u6708 5\u6708 6\u6708 7\u6708 8\u6708 9\u6708 10\u6708 11\u6708 12\u6708".split(" "),eg:"\u4e00\u6708 \u4e8c\u6708 \u4e09\u6708 \u56db\u6708 \u4e94\u6708 \u516d\u6708 \u4e03\u6708 \u516b\u6708 \u4e5d\u6708 \u5341\u6708 \u5341\u4e00\u6708 \u5341\u4e8c\u6708".split(" "),Ng:[{pattern:"yy *[/\\s-] *mm *[/\\s-] *dd",na:"yMd"},{pattern:"yy *[\u5e74/\\s-] *mm *[\u6708/\\s-] *dd[\u65e5]?",
na:"yMMMd"},{pattern:"yyyy *[\\s] *mm *[\\s] *dd",na:"yMd"},{pattern:"yyyy *[\u5e74\\s] *mm *[\u6708\\s] *dd[\u65e5]?",na:"yMMMd"},{pattern:"dd *[./\\s-] *mm *[./\\s-] *yyyy",na:"yMd"},{pattern:"dd *[./\u65e5\\s-] *mm *[\u6708./\\s-] *yyyy[\u5e74]?",na:"yMMMd"},{pattern:"mm *[/\\s-] *dd",na:"yMd"},{pattern:"mm *[\u6708/\\s-] *dd[\u65e5]?",na:"yMMMd"},{pattern:"yyyy\u5e74 *mmm",na:"yMMM"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/f573cb6abb6682a6.js.map