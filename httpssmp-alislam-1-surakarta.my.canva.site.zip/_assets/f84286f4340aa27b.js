(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[96819],{

/***/ 734191:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var $mc;__c.d3=function({loop:a=!1,KN:b,KO:c,qf:d,rendererSettings:e,Zl:f}){const g=Xmc(null),h=Xmc(void 0);Ymc(()=>{const k=__c.z(g.current),l=__c.Dv.Ob&&!d,m=l?void 0:[c,c];h.current=Zmc().loadAnimation({autoplay:l,container:k,initialSegment:m,loop:a??!1,path:b,renderer:"svg",rendererSettings:e});a||h.current.addEventListener("complete",()=>{f?.()});return()=>{h.current&&h.current.destroy()}},[]);return $mc("div",{className:"sH8e1w",ref:g})};$mc=__webpack_require__(322594).jsx;var anc=__webpack_require__,bnc=anc(802496),Zmc=anc.n_x(bnc);var cnc=__webpack_require__(205482),Ymc=cnc.useEffect,Xmc=cnc.useRef;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/f84286f4340aa27b.js.map